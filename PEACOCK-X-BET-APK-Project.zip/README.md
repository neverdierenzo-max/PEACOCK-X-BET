# PEACOCK X BET — Android APK project

This project wraps the current HTML build into an Android WebView app.

## Build on GitHub
1. Upload this project to the root of your GitHub repository.
2. Open **Actions**.
3. Run **Build PEACOCK X BET APK** (or push to `main`).
4. Open the completed workflow run.
5. Download the `PEACOCK-X-BET-debug-apk` artifact and extract the APK.

The HTML is bundled locally inside the APK, so the app opens without needing the HTML file separately.

Note: the current HTML logic is still local/demo logic; wrapping it as an APK does not turn payment or coin handling into a real-money backend.
